<?php
	include("includes/header.php");
?>

<div id="content">
	<div class="post">
		<h2 class="title"><a href="#">Könyvesbolt menedzselő rendszer</a></h2>
			<p class="meta"></p>
			<div class="entry">
				A te dízájnod
			</div>
	</div>
</div><!-- end #content -->

<?php
	include("includes/footer.php");
?>