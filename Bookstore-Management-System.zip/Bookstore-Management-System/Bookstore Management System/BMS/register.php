<?php
	include("includes/header.php");
?>

<div id="content">
	<div class="post">
		<h2 class="title"><a href="#">Felhasználó regisztrálás</a></h2>
			<p class="meta"></p>
			<div class="entry">
				
				<form class="register" action="register_process.php" method="post">
					
					<?php
						if(isset($_GET['register']))
						{
							echo '<font color="red">Regisztráció sikeres volt.</font>';
							echo '<br><br>';
						}
					?>

					Teljes név :<br>
					<input type="text" name="fnm" class="txt">
						<?php
							if(isset($_SESSION['error']['fnm']))
							{
								echo '<font color="red">'.$_SESSION['error']['fnm'].'</font>';
							}
						?>
					<br><br>

					Felhasználónév :<br>
					<input type="text" name="unm" class="txt">
						<?php
							if(isset($_SESSION['error']['unm']))
							{
								echo '<font color="red">'.$_SESSION['error']['unm'].'</font>';
							}
						?>
					<br><br>

					Jelszó :<br>
					<input type="password" name="pwd" class="txt">
						<?php
							if(isset($_SESSION['error']['pwd']))
							{
								echo '<font color="red">'.$_SESSION['error']['pwd'].'</font>';
							}
						?>
					<br><br>

					Jelszó megerősítés :<br>
					<input type="password" name="cpwd" class="txt"><br><br>

					E-mail :<br>
					<input type="text" name="email" class="txt">
						<?php
							if(isset($_SESSION['error']['email']))
							{
								echo '<font color="red">'.$_SESSION['error']['email'].'</font>';
							}
						?>
					<br><br>

					Kapcsolat felvételi szám :<br>
					<input type="text" name="cno" class="txt">
						<?php
							if(isset($_SESSION['error']['cno']))
							{
								echo '<font color="red">'.$_SESSION['error']['cno'].'</font>';
							}
						?>
					<br><br>

					Biztonsági kérdés :<br>
					<select name="question" class="txt">
						<option>Mi a kedvenc filmed?</option>
						<option>Ki a kedvenc színészed</option>
					</select>
						<?php 
							if(isset($_SESSION['error']['que']))
							{
								echo '<font color="red">'.$_SESSION['error']['que'].'</font>';
							}
						?>
					<br><br>

					Biztonsági válasz :<br>
					<input type="text" name="answer">
						<?php 
							if(isset($_SESSION['error']['answer']))
							{
								echo '<font color="red">'.$_SESSION['error']['answer'].'</font>';
							}
						?>
					<br><br>

					<input type="submit" class="btn" value="Register">

					<p class="login_link">
						<a href="login.php" style="margin-left: 145px; text-decoration: none">Már létezik ez a fiók - Fiók</a>
					</p>

				</form>

				<?php
					unset($_SESSION['error']);
					unset($_GET['register']);
				?>

			</div>
	</div>
</div><!-- end #content -->

<?php
	include("includes/footer.php");
?>