<?php

	session_start();

	include("includes/connection.php");

	if(!empty($_POST))
	{
		extract($_POST);
		extract($_SESSION);

		$_SESSION['error']=array();

		if(empty($fnm))
		{
			$_SESSION['error'][]="Adja meg a teljes nevét";
		}

		if(empty($add))
		{
			$_SESSION['error'][]="Adja meg a teljes címét";
		}

		if(empty($pc))
		{
			$_SESSION['error'][]="Adja meg városának az írányítószámát";
		}

		if(empty($city))
		{
			$_SESSION['error'][]="Adja meg városát";
		}

		if(empty($state))
		{
			$_SESSION['error']['state']="Adja meg államát";
		}

		if(empty($mno))
		{
			$_SESSION['error'][]="Adja meg telefonszámát";
		}
		else if(!is_numeric($mno))
		{
			$_SESSION['error'][]="Adja meg telefonszámát számokkal";
		}

		if(!empty($_SESSION['error']))
		{
			header("location:order.php");
		}
		else
		{
			$rid=$_SESSION['client']['id'];

			$q="INSERT INTO `bms`.`order` (
						`o_id` ,
						`o_name` ,
						`o_address` ,
						`o_pincode` ,
						`o_city` ,
						`o_state` ,
						`o_mobile` ,
						`o_rid`
						)
						VALUES (
						NULL , '$fnm', '$add', '$pc', '$city', '$state', '$mno', '$rid'
						)";

			$res=mysql_query($q,$link);

			header("location:order.php?order");
		}
	}
	else
	{
		header("location:order.php");
	}
?>