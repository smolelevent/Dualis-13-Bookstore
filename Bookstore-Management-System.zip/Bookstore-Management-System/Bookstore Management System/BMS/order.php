<?php
	include("includes/header.php");

	include("includes/connection.php");
?>

<div id="content">
	<div class="post">
		<h2 class="title"><a href="#">Rendelés - Cash On szállítás</a></h2>
			<p class="meta"></p>
			<div class="entry">
				
				<form style="color: black" role="form" action="order_process.php" class="register" method="post">
					
					<?php
                        if(isset($_GET['order']))
                        {
                            echo '<font style="color:red">Order Successfully Placed</font><br><br>';
                        }
                    ?>

                    <?php
						if(!empty($_SESSION['error']))
						{
							foreach($_SESSION['error'] as $er)
							{
								echo '<font color="red">'.$er.'</font><br>';
							}
							unset($_SESSION['error']);
						}
					?>

					<br>

					Teljes név :<br>
					<input type="text" name="fnm" class="txt" placeholder="First Name or Surname"><br><br>


					Cím :<br>
					<input type="text" name="add" class="txt" placeholder="Address"><br><br>


					Pin kód :<br>
					<input type="text" name="pc" class="txt" placeholder="City Pin Code"><br><br>


					Város :<br>
					<input type="text" name="city" class="txt" placeholder="City"><br><br>


					Állam: :<br>
					<input type="text" name="state" class="txt" placeholder="State"><br><br>


					Telefonszám :<br>
  					<input type="text" name="mno" class="txt" placeholder="Mobile Number"><br><br>

					<button type="submit" name="sub" class="btn btn-default">Megerősítés és tovább haladás</button>
						
				</form>

			</div>
	</div>
</div><!-- end #content -->

<?php
	include("includes/footer.php");
?>