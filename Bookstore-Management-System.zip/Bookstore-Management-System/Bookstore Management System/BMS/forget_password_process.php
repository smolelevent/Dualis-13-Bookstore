<?php

	session_start();

	include("includes/connection.php");

	if(!empty($_POST))
	{
		$_SESSION['error']=array();
		extract($_POST);

		if(empty($unm))
		{
			$_SESSION['error']['unm']="Kérjük adja meg a felhasználónevét";
		}
		else if(empty($row))
		{
			$_SESSION['error']['unm']="Rossz felhasználónév";
		}
		else if(empty($answer))
		{
			$_SESSION['error']['unm']="Kérjük adja meg a biztonsági kérdést";
		}

		if(empty($unm))
		{
			$_SESSION['error']['answer']="Kérjük adja meg a biztonségi kérdésre a választ";
		}

		if(empty($pwd) || empty($cpwd))
		{
			$_SESSION['error']['pwd']="Kérjük adja meg az új jelszavát";
		}
		else if($pwd != $cpwd)
		{
			$_SESSION['error']['pwd']="A jelszó nem egyezik";
		}

		$q="select * from register where r_unm='$unm'";

		$res=mysql_query($q,$link);

		$row=mysql_fetch_assoc($res);

		if(!empty($_SESSION['error']))
		{
			header("location:forget_password.php");
		}
		else
		{
			echo "jó";
		}
	}
	else
	{
		header("location:forget_password.php");
	}

?>