<?php
	
	session_start();

	if(!empty($_POST))
	{
		extract($_POST);
		$_SESSION['error']=array();

		if(empty($fnm))
		{
			$_SESSION['error']['fnm']="Kérjük teljes nevét adja meg";
		}
		
		if(empty($mno))
		{
			$_SESSION['error']['mno']="Kérjük teljes nevét adja meg";
		}
		else if(!empty($mno))
		{
			if(!is_numeric($mno))
			{
				$_SESSION['error']['mno']="Kérjük adja meg a szám alapú telefonszámát";
			}
		}

		if(empty($msg))
		{
			$_SESSION['error']['msg']="Kérjük adja meg az üzenetet";
		}	

		if(empty($email))
		{
			$_SESSION['error']['email']="Kérjük adja meg az e-mailt";
		}

		if(!empty($error))
		{
			foreach($error as $er)
			{
				echo '<font color="red">'.$er.'</font><br>';
			}
		}
		else
		{
			include("includes/connection.php");

			$t=time();

			$q="insert into contact(c_fnm,c_mno,c_email,c_msg,c_time) values('$fnm','$mno','$email','$msg','$t')";

			mysql_query($q,$link);

			header("location:contact.php");
		}
	}
	else
	{
		header("location:contact.php");
	}
?>