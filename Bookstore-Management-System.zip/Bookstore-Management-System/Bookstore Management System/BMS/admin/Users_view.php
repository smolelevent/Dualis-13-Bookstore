<?php
    include("includes/header.php");

    include("../includes/connection.php");
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Felhaszn�l�k megtekint�se</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            K�nyvek list�ja
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Sorsz�m</th>
                                            <th>Regisztr�ci�s ID</th>
                                            <th>Teljes n�v</th>
                                            <th>Felhaszn�l�n�v</th>
                                            <th>Kontakt sorsz�m</th>
                                            <th>E-Mail</th>
                                            <th>Regisztr�ci�s d�tum</th>
                                            <th>M�velet</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                            $r_q="select * from register";

                                            $r_res=mysql_query($r_q,$link);

                                            $count=1;

                                            while($r_row=mysql_fetch_assoc($r_res))
                                            {
                                                echo '<tr class="odd gradeX">
                                                          <td>'.$count.'</td>
                                                          <td>'.$r_row['r_id'].'</td>
                                                          <td>'.$r_row['r_fnm'].'</td>
                                                          <td>'.$r_row['r_unm'].'</td>
                                                          <td>'.$r_row['r_cno'].'</td>
                                                          <td>'.$r_row['r_email'].'</td>
                                                          <td>'.@date("d-M-y",$book_row['r_time']).'</td>
                                                          <td align="center"><a style="color: red;" href="process_users_del.php?id='.$r_row['r_id'].'">x</a></td>
                                                      </tr>';
                                                $count++;
                                            }

                                        ?>
                                            
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
    
        </div>
        <!-- /#page-wrapper -->
<?php
    include("includes/footer.php");
?>