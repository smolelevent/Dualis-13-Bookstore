<?php

	session_start();

	include("../includes/connection.php");

	if(!empty($_POST))
	{
		$_SESSION['error']=array();

		extract($_POST);

		if(empty($bnm))
		{
			$_SESSION['error']['bnm']="Adja meg a k�nyv nev�t:";
		}

		if(empty($desc))
		{
			$_SESSION['error']['desc']="Adja meg a k�nyv le�r�s�t:";
		}

		if(empty($price))
		{
			$_SESSION['error']['price']="Adja meg a k�nyv �r�t:";
		}
		else if(!is_numeric($price))
		{
			$_SESSION['error']['price']="Adja meg a k�nyv �r�t (sz�mokkal):";
		}

		if(empty($_FILES['b_img']['name']))
		{	$_SESSION['error']['b_img'] = "K�rj�k adjon meg egy f�jlt";
		}
		else if($_FILES['b_img']['error']>0)
		{	$_SESSION['error']['b_img'] = "Hiba a f�jl felt�lt�sekor";
		}	
		else if(!(strtoupper(substr($_FILES['b_img']['name'],-4))==".JPG" || strtoupper(substr($_FILES['b_img']['name'],-5))==".JPEG"|| strtoupper(substr($_FILES['b_img']['name'],-4))==".GIF"))
		{
			$_SESSION['error']['b_img'] = "rossz f�jl t�pus";
		}	

		//image validation

		$upper=strtoupper(substr($_FILES['b_img']['name'],-4));

		
		if(!empty($_SESSION['error']))
		{
			header("location:book_edit.php");
		}
		else
		{
			$t=time();
		
			//move_uploaded_file($_FILES['b_img']['tmp_name'],"../book_img/".$img_nm);


			move_uploaded_file($_FILES['b_img']['tmp_name'],"../book_img/".$_FILES['b_img']['name']);
			$b_img="book_img/".$_FILES['b_img']['name'];

			$q="update book set b_nm='$bnm', b_cat='$cat', b_desc='$desc', b_price=$price, b_img='$b_img', b_time='$t' where b_id=".$id;

			$res=mysql_query($q,$link);

			header("location:book_view.php");
		}
	}
	else
	{
		header("location:book_view.php");
	}

?>