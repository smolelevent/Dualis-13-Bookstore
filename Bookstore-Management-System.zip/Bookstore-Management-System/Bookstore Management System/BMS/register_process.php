<?php
	
	session_start();

	if(! empty($_POST))
	{
		extract($_POST);
		$_SESSION['error']=array();

		if(empty($fnm))
		{
			$_SESSION['error']['fnm']="Kérjük adja meg a teljes nevét";
		}

		if(empty($unm))
		{
			$_SESSION['error']['unm']="Kérjük adja meg a felhasználónevét";
		}

		if(empty($pwd) || empty($cpwd))
		{
			$_SESSION['error']['pwd']="Kérjük adja meg a telefonszámát";
		}
		else if($pwd != $cpwd)
		{
			$_SESSION['error']['pwd']="A jelszavak nem egyeznek";
		}
		else if(strlen($pwd)<8)
		{
			$_SESSION['error']['pwd']="Kérjük adjon meg 8 karakteres jelszót";
		}

		if(empty($email))
		{
			$_SESSION['error']['email']="Kérjük adja meg az E-mailét";
		}
		else if(!ereg("^[a-z0-9_]+[a-z0-9_.]*@[a-z0-9_-]+[a-z0-9_.-]*\.[a-z]{2,5}$",$email))
		{
			$_SESSION['error']['email']="Kérjük egy érvényes E-mailt adjon meg";
		}

		if(empty($answer))
		{
			$_SESSION['error']['answer']="Kérjük adja meg a biztonsági kérdésre való választ";
		}

		if(empty($cno))
		{
			$_SESSION['error']['cno']="Kérjük adja meg telefonszámát";
		}
		if(!empty($cno))
		{
			if(!is_numeric($cno))
			{
				$_SESSION['error']['cno']="Kérjük adja meg a telefonszámát számokkal";
			}
		}

		if(!empty($error))
		{
			foreach($error as $er)
			{
				echo '<font color="red">'.$er.'</font><br>';
			}
		}

		if(! empty($_SESSION['error']))
		{
			header("location:register.php");
		}

		else
		{
			include("includes/connection.php");

			$t=time();

			$q="insert into register(r_fnm,r_unm,r_pwd,r_cno,r_email,r_question,r_answer,r_time) values('$fnm','$unm','$pwd','$cno','$email','$question','$answer','$t')";

			mysql_query($q,$link);

			header("location:register.php?register");
		}
	}
	else
	{
		header("location:register.php");
	}

?>